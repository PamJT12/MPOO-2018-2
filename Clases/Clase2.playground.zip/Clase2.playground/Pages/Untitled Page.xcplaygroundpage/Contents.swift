//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

var nombre = "Pam"

var edad: Int = 20


//Incrementadores y Decrementadores
edad += 1
edad -= 1

// V- valores
// M - Metodos

//Operadores de comparacion

(2>3)
(3>2)
!(true) // ! sirve para negar

//Concatenar
 (2>3) && (3<2)
 (2<3) || (3>2)

//Estructuras de comparaciòn

if 8 % 2 == 0 {
    print("Es par")
}
else{
    print ("Es impar")
}

// else if   sirve para ahorrar ciclos de reloj, porque interrumpe el ciclo si no se cumple la condicion

//Operador ternario

let a = 5
let b = 10

let min = a < b ? a : b

// if a < b {
//  min = a
// }
// else {
//  min = b }

//encapsulamiento de variables

//if a > b {
 //   var max = a }
//else {
//    var max = b
//}

//print (max) ->  no se imprime ningun valor porque pierde su valor despues de que termina el ciclo


//Ciclo While

var sum = 1
while sum < 100 {
    sum += 1
}


//Repeat (Do While)

repeat {
    sum += 2}
while sum < 1000

//Factorial

var num = 1
var num1 = 1

repeat {
    num = num * num1
    num1 = num1 + 1
} while num1 < 7

print (num)

//
var factorial = 1
var numero = 6

while numero >= 1 {
    factorial = factorial * numero
    numero -= 1
    
}
print (factorial)

//break para romper un ciclo


//Control de flujo avanzado

let rango = 0 ... 5  //Rango cerrado
print (rango)

let medioRango = 0..<5  // Medio Rango

let count = 10
var suma = 0
for i in 1...count {
    suma += i
}



let count1 = 10
var suma1 = 0
for _ in 1...count1 {  // _ holder
    suma += 1
}

suma = 0
for i in 1...count where i % 2 == 1{
    sum += i
}
print (suma)








