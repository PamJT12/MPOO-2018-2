//: [Previous](@previous)

import UIKit

var str = "Hello, playground"

//: [Next](@next)

//Sentencias Switch

let number = 10

switch  number {
case 0:
    print ("cero")
default:
    print ("No es cero")
}

switch number{
case 10:
    print ("Es 10")
default:
    break
}

//
let string = "perro"

switch string{
case "perro", "gato":
    print ("Es un animal domestico")
default:
    print ("No es un animal domestico")
    
//Switch Avanzado
    
let hourOfDay = 12
var timeOfDay: String
    
switch hourOfDay {
case 1,2,3,4,5:
    timeOfDay = "Es muuuy temprano"
case 6,7,8,9,10,11:
    timeOfDay = "Es temprano"
case 12,13,14,15,16:
    timeOfDay = "Es dos dos temprano"
case 17,18,19:
    timeOfDay = "Es tarde"
case 20,21,22,23:
    timeOfDay = "Es tarde noche"
default:
    timeOfDay = "No es un horario vàlido"
    }
print (timeOfDay)

//Usando Rangos

    
    switch hourOfDay {
    case 1...5:
        timeOfDay = "Es muuuy temprano"
    case 6...11:
        timeOfDay = "Es temprano"
    case 12...16:
        timeOfDay = "Es dos dos temprano"
    case 17...19:
        timeOfDay = "Es tarde"
    case 20...23:
        timeOfDay = "Es tarde noche"
    default:
        timeOfDay = "No es un horario vàlido"
    }
    print (timeOfDay)


    switch number {
    case _ where number % 2 == 0:
        print ("Es par")
    default:
        print("Es impar")}

let coord2D: (Int, Int) = (3, 2)
let coord3D = (x: 0, y: 1, z: 0)

switch coord3D{
case (0,0,0):
    print ("En el origen")
case (_,0,0):
    print( "En el eje de las x")
case (0,_,0):
    print ("En el eje de las y")
case (0,0,_):
    print ("En el eje de las z")
default:
    print("En algun lugar del espacio")
    }
    
        
}


