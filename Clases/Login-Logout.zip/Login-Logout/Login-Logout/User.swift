//
//  User.swift
//  Login-Logout
//
//  Created by MacBook on 19/04/18.
//  Copyright © 2018 MacBook7. All rights reserved.
//

import Foundation

struct Usuario{
    var nombre: String
    var apellido: String
    var usuario: String
    var password: String
}
