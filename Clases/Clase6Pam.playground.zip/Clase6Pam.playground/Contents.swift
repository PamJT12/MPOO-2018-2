//: Playground - noun: a place where people can play

import UIKit


//Estructuras - tienen constructor sintetico sirven para modelar datos no heredan
struct Alumno{
    let numCuenta: String
    let nombre: String
    var edad: Int
    var carrera: String
}

//Clases 

class Profesor{
    let numTrabajador: Int //= 0
    let nombre: String //= ""
    
    init (nombre: String, numTrabajador: Int){
        self.nombre = nombre
        self.numTrabajador = numTrabajador
    }


}


var alumno = Alumno(numCuenta: "314034443", nombre:"Pam", edad: 20, carrera: "Electrica" )

alumno.carrera = "Contaduria"

