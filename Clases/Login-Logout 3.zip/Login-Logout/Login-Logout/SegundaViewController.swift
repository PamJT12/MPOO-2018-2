//
//  SegundaViewController.swift
//  Login-Logout
//
//  Created by MacBook on 19/04/18.
//  Copyright © 2018 MacBook7. All rights reserved.
//

import UIKit

class SegundaViewController: UIViewController {

    @IBOutlet weak var nombreText: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //var nombreText = "\(Usuario.nombre) \(Usuario.apellido)"
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func logOut(_ sender: UIButton) {
        
    }
    
   
}
