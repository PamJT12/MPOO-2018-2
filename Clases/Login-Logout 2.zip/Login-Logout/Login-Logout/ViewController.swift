//
//  ViewController.swift
//  Login-Logout
//
//  Created by MacBook on 19/04/18.
//  Copyright © 2018 MacBook7. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var usuarioText: UITextField!
    @IBOutlet weak var passwordText: UITextField!
    
    var valores = UserDefaults.standard
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let userName = valores.object(forKey: "informacion1"), let password = valores.object(forKey: "informacion2"){
            usuarioText.text = userName as! String
            passwordText.text = password as! String
            var cadenaMagica1 = userName as! String
            var cadenaMagica2 = password as! String
            for user in usuarios{
                if cadenaMagica1 == user.usuario, cadenaMagica2 == user.password{
                    print("Usuario validado")
                    valores.set(userName, forKey: "informacion1")
                    valores.set(password, forKey: "informacion2")
                    performSegue(withIdentifier: "vista2", sender: self)
            }
        
            }
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func Login(_ sender: UIButton) {
        var validate: Bool = true
        if let userName = usuarioText.text, let password = passwordText.text{
            for user in usuarios{
                if userName == user.usuario, password == user.password{
                    print("Usuario validado")
                     valores.set(userName, forKey: "informacion1")
                     valores.set(password, forKey: "informacion2")
                    shouldPerformSegue(withIdentifier: "vista2", sender: self)
                    break
                }else{
                    validate = false
                }
            }
        }
        
        if !validate{
            showError()
        }
    }
    
    @IBAction func Register(_ sender: UIButton) {
        shouldPerformSegue(withIdentifier: "vista3", sender: self)
    }
    
    func showError(){
        let errorAlert = UIAlertController(title: "Error", message: "Sus datos no son correctos", preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "Ok", style: .cancel, handler: nil)
        
        errorAlert.addAction(okAction)
        
        present(errorAlert, animated: true, completion: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "vista2"{
            print("Ejecutando el nextSegue")
        }
    }
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        if identifier == "vista2" || identifier == "vista3" {
            return true
        }
        else{
            return false
        }
    }
    
    
    
    }



