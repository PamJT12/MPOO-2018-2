//
//  SegundaViewController.swift
//  Login-Logout
//
//  Created by MacBook on 19/04/18.
//  Copyright © 2018 MacBook7. All rights reserved.
//

import UIKit

class SegundaViewController: UIViewController {

    @IBOutlet weak var nombreText: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func logOut(_ sender: UIButton) {
        
        UserDefaults.standard.set("", forKey: "informacion2")
        navigationController?.popViewController(animated: true)
        

        
//        let salirClosure = {( action: UIAlertAction) -> Void {
//            shouldPerformSegue(withIdentifier: "regreso", sender: self)
//        //}
//
//        let salir = UIAlertController(title: "Salir", message: "Tu sesión está por terminar", preferredStyle: .alert)
//
//        let yesAction = UIAlertAction(title: "Deseo salir", style: .default, handler: nil)
//
//        let noAction = UIAlertAction(title: "Deseo quedarme", style: .cancel, handler: nil)
//
//        salir.addAction(yesAction)
//        salir.addAction(noAction)
       
     //(   present(salir, animated: true, completion: nil)
   }
    
    
}
