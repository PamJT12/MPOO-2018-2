//: Playground - noun: a place where people can play

import UIKit

//closure: funciones que pueden ser manejadas por variables deben llevar "in"

var miniClosure: (Int, Int) -> Int //definicion/firma/enumeracion del closure
var multiplicaClosure: (Int,Int) -> Int

miniClosure = { (a: Int, b:Int) -> Int in
    return a + b
}

miniClosure(3,2)

//Los closures permiten anidamiento de funciones

multiplicaClosure = { (a: Int, b: Int)-> Int in
    return a * b
}

func operacion(_ closure:(Int, Int) -> Int, a: Int, b: Int){
    print(closure(a,b))
}

operacion(miniClosure, a: 10, b: 50)
operacion(multiplicaClosure, a: 20, b: 50)

miniClosure = {(a, b) in
    return a + b
}

miniClosure = {
    $0 + $1
}

var noReturnClosure: () -> Void = {
    print ("No regresa nada")
}

var contador = 0

var incrementar = {
    contador += 1
}

incrementar()
incrementar()
incrementar()

print(contador)

func contadorClosure() -> () -> Int { //funcion llamada contadorClosure que regresara un closure que regresa un Int
    var  contador = 0
    let incrementaClosure: () -> Int = {
        contador += 1
        return contador
    }
    return incrementaClosure
}

let contador1 = contadorClosure()
let contador2 = contadorClosure()

contador1()
contador1()
contador2()

//En este caso las variables let pueden cambiar de valor por que lo que contienen son referencias y no valores

let names = ["Arya", "Snow", "Lenne", "LycanRock"]
names.sorted()

print(names.sorted{
    $0.count > $1.count
})

print(names.sorted{
    $0.count < $1.count
})

let numeros = [1,4,2,5,3,6,4,7,5,8,9]

numeros.forEach{
    print("\($0)")
}

let precios = [1.4, 20.3, 9.56, 30.45]

let preciosCaros = precios.filter{ //Filtrar elementos
    return $0 > 5
}.sorted()

print(preciosCaros)

let preciosDescuento = precios.map{  //Ejecutar accion por cada elemento
    return $0 * 0.8
}

print(preciosDescuento.sorted())

//Castear
let userInput = ["0", "11", "hola", "42"]
let numeros1 = userInput.flatMap{ //Desenvuelve los optionals y elimina nils
    Int($0)
}
print(numeros1)

let suma = precios.reduce(0){ //se inicializa la variable
    return $0 + $1
}

print(suma)

let animalitos = ["🦉": 3, "🐼": 4, "🦊": 5 , "月": 6]

let todosLosAnimales = animalitos.reduce(into: []){
    (result, this: (key: String, value: Int)) in
    for _ in 0 ..< this.value{
        result.append(this.key)
    }
}
print (todosLosAnimales)

var animalesEliminados = todosLosAnimales.dropFirst()
print(animalesEliminados)

animalesEliminados = animalesEliminados.dropLast(4)
print (animalesEliminados)

todosLosAnimales.suffix(2)
todosLosAnimales.prefix(3)












