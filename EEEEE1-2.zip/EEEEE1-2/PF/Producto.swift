//
//  Producto.swift
//  PF
//
//  Created by MacBook on 05/06/18.
//  Copyright © 2018 MacBook. All rights reserved.
//

import Foundation
struct Product {
    var nombre: String
    var imagen: String
    var precio: Double
    var cantidad: Int  // Cantidad en inventario
    var existencia: Bool //Si existe o no el producto
    var vendidos: Int //No. de productos vendidos
}

var indexP = 0

let Galletas = Product(nombre: "Galletas", imagen: "galletas", precio: 12.00, cantidad: 5, existencia: true, vendidos: 0)
let PAn = Product(nombre: "Pan", imagen: "Pan", precio: 20.00, cantidad: 15, existencia: true, vendidos: 0)
let Leche = Product(nombre: "Leche", imagen: "leche", precio: 30.00, cantidad: 25, existencia: true, vendidos: 0 )
let Vino = Product(nombre: "Vino", imagen: "vino", precio: 25.00, cantidad: 10, existencia: true, vendidos: 0)


var productos = [Galletas,PAn,Leche,Vino]
//var productos: [Product] = []

