//
//  RegistroProd.swift
//  PF
//
//  Created by MacBook on 05/06/18.
//  Copyright © 2018 MacBook. All rights reserved.
//

import UIKit

class RegistroProd: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    @IBOutlet weak var NombreRP: UITextField!
    @IBOutlet weak var PrecioRP: UITextField!
    @IBOutlet weak var CantidadRP: UITextField!
    @IBOutlet weak var FotoRP: UIImageView!
    
    let imageSelect: UIImagePickerController = UIImagePickerController ()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        imageSelect.delegate = self
       

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        
        if let selectImage = info[UIImagePickerControllerOriginalImage] as? UIImage{
            
            FotoRP.image = selectImage
            dismiss(animated: true, completion: nil)
        }
        
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        print("Cancelo el picker")
        dismiss(animated: true, completion: nil)
    }
    
    
    @IBAction func ElegirImagen(_ sender: UIButton) {
        if UIImagePickerController.isSourceTypeAvailable(.photoLibrary){
            
            imageSelect.allowsEditing = false
            imageSelect.sourceType = .photoLibrary
            
            present(imageSelect, animated: true, completion: nil)
        }
    }
    
//    @IBAction func RegistrarProducto(_ sender: UIButton) {
//        let nuevo = Product(nombre: NombreRP.text!, imagen: <#String#>, precio: Double(PrecioRP.text!)!, cantidad: Int(CantidadRP.text!)!, existencia: true, vendidos: 0)
//        productos.append(nuevo)
//        print("Producto registrado")
//        print(productos)
//    }

}
