//
//  DetailViewController.swift
//  PF
//
//  Created by macbook on 11/06/18.
//  Copyright © 2018 MacBook. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {
    
    @IBOutlet weak var ImagenProd: UIImageView!
    
    @IBOutlet weak var Name: UILabel!
    
    @IBOutlet weak var segmented: UISegmentedControl!

    @IBOutlet weak var VerCant: UILabel!
    
    @IBOutlet weak var confirmar: UIButton!
    
    var totalProducto: Double = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        Name.text = " \(productos[indexP].nombre) Precio: $ \(String(productos[indexP].precio))"
       ImagenProd.image = UIImage(named: productos[indexP].imagen)
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func CantVent(_ sender: UIStepper) {
        VerCant.text = String(Int(sender.value))
    }


    @IBAction func confirmar(_ sender: UIButton) {
        if segmented.selectedSegmentIndex == 0{
            
            self.mensajeAlerta("¿Quieres vender \(String(describing: VerCant.text!)) productos?")
            
        }else{
            self.mensajeAlerta("¿Quieres agregar \(String(describing: VerCant.text!)) productos?")
        }
    }
    
    
    func mensajeAlerta(_ mensaje: String){
        let alerta = UIAlertController(title:segmented.titleForSegment(at: segmented.selectedSegmentIndex), message: mensaje, preferredStyle: UIAlertControllerStyle.alert)
        
        let okAction = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler:  {(action: UIAlertAction) -> Void in
            
            if self.segmented.selectedSegmentIndex == 0{
                productos[indexP].cantidad = productos[indexP].cantidad - Int(self.VerCant.text!)!
                print(productos[indexP].cantidad)
//                let actTable = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "Tabla1") as! TableViewController
//                self.present(actTable,animated: true,completion: nil)
                
                self.totalProducto = productos[indexP].precio * Double(self.VerCant.text!)!
                
                totalVendido = totalVendido + self.totalProducto
                print(totalVendido)
                
                let Ventalista = ProductVendido(nombre: productos[indexP].nombre, cantidad: Int(self.VerCant.text!)!, precioTotal: self.totalProducto)
                listaVendidos.append(Ventalista)
                
                print(listaVendidos)
                
                
                
            } else{
                
                productos[indexP].cantidad = productos[indexP].cantidad + Int(self.VerCant.text!)!
                print(productos[indexP].cantidad)
                
//                 let actTable = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "Tabla1") as! TableViewController
//                self.present(actTable,animated: true,completion: nil)
            }
        })
        
        let cancel = UIAlertAction(title: "Cancelar", style: .cancel, handler: nil)
        
        
        alerta.addAction(okAction)
        alerta.addAction(cancel)
        
        present(alerta, animated: true, completion: nil)
        
        
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
