//
//  Cell2.swift
//  PF
//
//  Created by macbook on 11/06/18.
//  Copyright © 2018 MacBook. All rights reserved.
//

import UIKit

class Cell2: UITableViewCell {

    @IBOutlet weak var Producto: UILabel!
    
    @IBOutlet weak var Cantidad: UILabel!
    
    @IBOutlet weak var Total: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
