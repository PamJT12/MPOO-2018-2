//
//  VentasViewController.swift
//  PF
//
//  Created by MacBook on 05/06/18.
//  Copyright © 2018 MacBook. All rights reserved.
//

import UIKit

class VentasViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    
    @IBOutlet weak var VentasP: UITableView!
    
    @IBOutlet weak var TotalVenta: UILabel!
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listaVendidos.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell2 = tableView.dequeueReusableCell(withIdentifier: "celda2", for: indexPath) as! Cell2
        cell2.Producto.text = listaVendidos[indexPath.row].nombre
        cell2.Cantidad.text = String(listaVendidos[indexPath.row].cantidad)
        cell2.Total.text = String(listaVendidos[indexPath.row].precioTotal)
        
        return cell2
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()

        self.VentasP.delegate = self
        self.VentasP.dataSource = self
        TotalVenta.text = "Total de Venta: $ \(totalVendido)"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
