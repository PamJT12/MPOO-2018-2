//
//  Cell2.swift
//  PF
//
//  Created by MacBook on 05/06/18.
//  Copyright © 2018 MacBook. All rights reserved.
//

import UIKit

class Cell2: UITableViewCell {

    
}
