//
//  Vendido.swift
//  PF
//
//  Created by MacBook on 05/06/18.
//  Copyright © 2018 MacBook. All rights reserved.
//

import Foundation

struct ProductVendido {
    var nombre: String
    var cantidad: Int
    var precioTotal: Double
    
}
var totalVendido: Double = 0.0

var listaVendidos: [ProductVendido] = []
