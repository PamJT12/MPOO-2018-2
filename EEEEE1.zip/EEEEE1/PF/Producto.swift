//
//  Producto.swift
//  PF
//
//  Created by MacBook on 05/06/18.
//  Copyright © 2018 MacBook. All rights reserved.
//

import Foundation
struct Product {
    var nombre: String
    //var foto: String
    var precio: Double
    var cantidad: Int  // Cantidad en inventario
    var existencia: Bool //Si existe o no el producto
    var vendidos: Int //No. de productos vendidos
}


let Galletas = Product(nombre: "Galletas", precio: 12.00, cantidad: 15, existencia: true, vendidos: 0)
let PAn = Product(nombre: "Pan", precio: 20.00, cantidad: 15, existencia: true, vendidos: 0)
let Leche = Product(nombre: "Leche", precio: 30.00, cantidad: 15, existencia: true, vendidos: 0)
let Vino = Product(nombre: "Vino", precio: 25.00, cantidad: 15, existencia: true, vendidos: 0)

var productos = [Galletas,PAn,Leche,Vino]
