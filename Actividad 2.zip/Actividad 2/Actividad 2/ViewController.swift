//
//  ViewController.swift
//  Actividad 2
//
//  Created by macbook on 05/03/18.
//  Copyright © 2018 Potato labs mx. All rights reserved.
//

import UIKit


class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


    @IBOutlet weak var Imagen: UIImageView!
    @IBOutlet weak var slider: UISlider!
    @IBOutlet weak var label: UILabel!
    
    @IBAction func climaSlider(_ sender: UISlider) {
        let valor = slider.value
        label.text = String(Int(valor))
        switch valor {
        case 0...25:
            label.text = "Soleado"
            Imagen.image = UIImage(named: "soleado")
        case 25...50:
            label.text = "Despejado"
            Imagen.image = UIImage(named: "despejado")
        case 50...75:
            label.text = "Nublado"
            Imagen.image = UIImage(named: "nublado")
        case 75...100:
            label.text = "Lluvioso"
            Imagen.image = UIImage(named:"lluvia")
        default:
            Imagen.image = UIImage(named: "climas")
        }
        
    }
    
}

